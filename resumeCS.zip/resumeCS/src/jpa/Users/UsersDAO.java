package jpa.Users;

public interface UsersDAO {

	public boolean doPost(String users, String sPassword);
}
